"""
server/mqtt_publisher.py
-------------------------
MQTT publisher that sends sensor readings and events to a local
Mosquitto broker over TLS (port 8883).

Topics used (configurable in client_conf.json):
  iot/readings  — JSON sensor reading dicts
  iot/events    — JSON event dicts

The publisher is used by the sensor client loop in main.py.
The Mosquitto broker must be running locally and configured for TLS.
See README.md for Mosquitto setup instructions.

If the MQTT broker is unavailable, publishing silently logs a warning
instead of crashing the sensor loop.
"""

import json
import logging
import os

logger = logging.getLogger(__name__)

# Defensive paho-mqtt import
try:
    import paho.mqtt.client as mqtt
    MQTT_AVAILABLE = True
except ImportError:
    MQTT_AVAILABLE = False
    logger.warning("paho-mqtt not installed — MQTT publishing disabled")


class MQTTPublisher:
    """
    TLS MQTT publisher.

    Parameters
    ----------
    config : full configuration dict
    """

    def __init__(self, config: dict):
        self._available = MQTT_AVAILABLE
        if not MQTT_AVAILABLE:
            return

        mqtt_cfg = config.get("mqtt", {})
        self._broker_host = mqtt_cfg.get("broker_host", "127.0.0.1")
        self._broker_port = mqtt_cfg.get("broker_port", 8883)
        self._topic_readings = mqtt_cfg.get("topic_readings", "iot/readings")
        self._topic_events = mqtt_cfg.get("topic_events", "iot/events")
        self._use_tls = mqtt_cfg.get("use_tls", True)
        self._ca_cert = mqtt_cfg.get("ca_cert", "certs/ca.crt")
        self._client_cert = mqtt_cfg.get("client_cert", "certs/client.crt")
        self._client_key = mqtt_cfg.get("client_key", "certs/client.key")
        self._username = mqtt_cfg.get("username", "")
        self._password = mqtt_cfg.get("password", "")

        self._client = mqtt.Client(client_id="iot_sensor_client", clean_session=True)
        self._connected = False
        self._setup_client()

    def _setup_client(self):
        """Configure and connect the MQTT client."""
        try:
            if self._username:
                self._client.username_pw_set(self._username, self._password)

            if self._use_tls:
                ca_ok = os.path.exists(self._ca_cert)
                cert_ok = os.path.exists(self._client_cert)
                key_ok = os.path.exists(self._client_key)

                if ca_ok and cert_ok and key_ok:
                    self._client.tls_set(
                        ca_certs=self._ca_cert,
                        certfile=self._client_cert,
                        keyfile=self._client_key,
                    )
                    logger.info("MQTT TLS configured")
                else:
                    logger.warning(
                        "MQTT TLS cert files not found — connecting without TLS. "
                        "Run scripts/gen_certs.sh and configure Mosquitto."
                    )

            self._client.on_connect = self._on_connect
            self._client.on_disconnect = self._on_disconnect

            self._client.connect(self._broker_host, self._broker_port, keepalive=60)
            self._client.loop_start()
            logger.info(f"MQTT client connecting to {self._broker_host}:{self._broker_port}")
        except Exception as e:
            logger.warning(f"MQTT connection failed: {e}. MQTT publishing disabled.")
            self._available = False

    def _on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            self._connected = True
            logger.info("MQTT broker connected")
        else:
            self._connected = False
            logger.warning(f"MQTT connection refused — return code {rc}")

    def _on_disconnect(self, client, userdata, rc):
        self._connected = False
        if rc != 0:
            logger.warning(f"Unexpected MQTT disconnect — return code {rc}")

    def publish_reading(self, reading: dict):
        """Publish a single sensor reading to the readings topic."""
        self._publish(self._topic_readings, reading)

    def publish_event(self, event: dict):
        """Publish a detected event to the events topic."""
        self._publish(self._topic_events, event)

    def _publish(self, topic: str, payload: dict):
        if not self._available or not self._connected:
            logger.debug(f"MQTT publish skipped (unavailable/disconnected): {topic}")
            return
        try:
            message = json.dumps(payload)
            result = self._client.publish(topic, message, qos=1)
            if result.rc != 0:
                logger.warning(f"MQTT publish failed on {topic}: rc={result.rc}")
            else:
                logger.debug(f"MQTT published to {topic}")
        except Exception as e:
            logger.warning(f"MQTT publish error: {e}")

    def disconnect(self):
        """Cleanly disconnect from the broker."""
        if self._available and self._client:
            self._client.loop_stop()
            self._client.disconnect()
            logger.info("MQTT client disconnected")

    @property
    def is_available(self) -> bool:
        return self._available and self._connected
