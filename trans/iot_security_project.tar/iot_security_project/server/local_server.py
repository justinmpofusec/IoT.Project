"""
server/local_server.py
-----------------------
Local HTTPS server built with Flask.

Accepts sensor readings and events posted by the sensor client over a
self-signed TLS connection. This simulates a real IoT gateway architecture
while keeping everything on a single Raspberry Pi.

Endpoints
---------
  POST /readings   Accept a batch of sensor reading dicts
  POST /events     Accept a detected event dict
  GET  /health     Simple liveness check
  GET  /chain      Return the last N chain records
  GET  /status     Summary of records received so far

The server writes received data to its own DataLogger and BlockchainLogger
instances (separate from the client's) so the server-side chain can be
independently verified.

Security note
-------------
A self-signed certificate is used. In production you would use a CA-signed
certificate. For local development and this assignment, self-signed is
appropriate and the client sets verify=False (or the CA cert path).

Run as:
    python server/local_server.py
Or as a thread from main.py.
"""

import json
import logging
import os
import sys

# Make project root importable regardless of how the script is run
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from flask import Flask, request, jsonify

from storage.logger_setup import setup_logging
from storage.data_logger import DataLogger
from utils.helpers import load_config, ensure_directories, utc_now

logger = logging.getLogger(__name__)

app = Flask(__name__)

# Shared DataLogger instance (initialised in main / start_server)
_data_logger: DataLogger = None
_config: dict = {}


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/health", methods=["GET"])
def health():
    """Simple liveness probe."""
    return jsonify({"status": "ok", "timestamp": utc_now()}), 200


@app.route("/status", methods=["GET"])
def status():
    """Return a summary of the server's blockchain chain length."""
    chain_count = _data_logger.chain.get_record_count() if _data_logger else 0
    return jsonify({
        "status": "running",
        "chain_records": chain_count,
        "timestamp": utc_now(),
    }), 200


@app.route("/readings", methods=["POST"])
def receive_readings():
    """
    Accept a JSON list of sensor reading dicts from the client.
    Each reading is logged to the server's DataLogger and chain.
    """
    if not request.is_json:
        return jsonify({"error": "Content-Type must be application/json"}), 400

    data = request.get_json(silent=True)
    if not isinstance(data, list):
        return jsonify({"error": "Expected a JSON array of readings"}), 400

    accepted = 0
    for reading in data:
        if isinstance(reading, dict) and "sensor" in reading:
            _data_logger.log_reading(reading)
            accepted += 1
        else:
            logger.warning(f"Skipping malformed reading: {reading}")

    logger.info(f"Received {accepted}/{len(data)} readings from client")
    return jsonify({"accepted": accepted, "timestamp": utc_now()}), 200


@app.route("/events", methods=["POST"])
def receive_events():
    """
    Accept a single event dict or a list of event dicts from the client.
    """
    if not request.is_json:
        return jsonify({"error": "Content-Type must be application/json"}), 400

    data = request.get_json(silent=True)
    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        return jsonify({"error": "Expected a JSON object or array"}), 400

    for event in data:
        if isinstance(event, dict) and "event_type" in event:
            _data_logger.log_event(
                event.get("event_type", "unknown"),
                event.get("details", {}),
                event.get("severity", "warning"),
            )

    return jsonify({"status": "logged", "count": len(data), "timestamp": utc_now()}), 200


@app.route("/chain", methods=["GET"])
def chain_tail():
    """Return the last N records from the server's chain file."""
    n = min(int(request.args.get("n", 10)), 100)
    chain_path = _data_logger.chain.chain_path if _data_logger else "blockchain/server_chain.jsonl"

    records = []
    if os.path.exists(chain_path):
        with open(chain_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        for line in lines[-n:]:
            line = line.strip()
            if line:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    pass

    return jsonify({"records": records, "count": len(records)}), 200


# ---------------------------------------------------------------------------
# Server startup
# ---------------------------------------------------------------------------

def start_server(config: dict = None, data_logger: DataLogger = None):
    """
    Start the Flask HTTPS server.

    Parameters
    ----------
    config      : configuration dict (loaded from client_conf.json)
    data_logger : DataLogger instance to use for persistence
    """
    global _config, _data_logger

    if config is None:
        config = load_config()
    _config = config

    if data_logger is None:
        server_cfg = config.get("server", {})
        log_cfg = config.get("logging", {})
        chain_cfg = config.get("blockchain", {})
        _data_logger = DataLogger(
            sensor_log_path=log_cfg.get("sensor_log_path", "logs/sensor_readings_server.jsonl"),
            event_log_path=log_cfg.get("event_log_path", "logs/events_server.jsonl"),
            chain_path=chain_cfg.get("chain_path", "blockchain/server_chain.jsonl"),
        )
    else:
        _data_logger = data_logger

    server_cfg = config.get("server", {})
    host = server_cfg.get("host", "127.0.0.1")
    port = server_cfg.get("port", 8443)
    use_tls = server_cfg.get("use_tls", True)
    cert_path = server_cfg.get("cert_path", "certs/server.crt")
    key_path = server_cfg.get("key_path", "certs/server.key")

    ssl_context = None
    if use_tls:
        if os.path.exists(cert_path) and os.path.exists(key_path):
            ssl_context = (cert_path, key_path)
            logger.info(f"TLS enabled | cert={cert_path}")
        else:
            logger.warning(
                f"TLS cert/key not found at {cert_path}/{key_path}. "
                "Falling back to plain HTTP. Run scripts/gen_certs.sh to generate certs."
            )

    _data_logger.log_system("Server starting", {"host": host, "port": port, "tls": ssl_context is not None})

    logger.info(f"Starting local server on {'https' if ssl_context else 'http'}://{host}:{port}")
    app.run(host=host, port=port, ssl_context=ssl_context, debug=False, use_reloader=False)


if __name__ == "__main__":
    setup_logging()
    config = load_config()
    start_server(config)
