"""
server/https_client.py
-----------------------
Thin HTTPS client used by the sensor loop to POST readings and events
to the local Flask server (server/local_server.py).

Uses urllib (stdlib only, no requests library needed) so there is one
fewer dependency. For a self-signed cert, TLS verification can be
disabled for local development or you can pass the CA cert path.
"""

import json
import logging
import ssl
import urllib.error
import urllib.request
from urllib.parse import urljoin

logger = logging.getLogger(__name__)


class HTTPSClient:
    """
    Simple HTTPS POST client for the local server.

    Parameters
    ----------
    config : full configuration dict
    """

    def __init__(self, config: dict):
        server_cfg = config.get("server", {})
        host = server_cfg.get("host", "127.0.0.1")
        port = server_cfg.get("port", 8443)
        use_tls = server_cfg.get("use_tls", True)

        scheme = "https" if use_tls else "http"
        self._base_url = f"{scheme}://{host}:{port}"

        # For local self-signed certs, skip verification
        # In production, provide the CA cert path instead
        self._ssl_context = ssl.create_default_context()
        self._ssl_context.check_hostname = False
        self._ssl_context.verify_mode = ssl.CERT_NONE

        self._available = True
        logger.info(f"HTTPSClient targeting {self._base_url}")

    def post_readings(self, readings: list) -> bool:
        """
        POST a list of reading dicts to /readings.
        Returns True on success, False on failure.
        """
        return self._post("/readings", readings)

    def post_events(self, events: list) -> bool:
        """
        POST a list of event dicts to /events.
        Returns True on success, False on failure.
        """
        return self._post("/events", events)

    def check_health(self) -> bool:
        """GET /health — returns True if server is reachable."""
        url = urljoin(self._base_url, "/health")
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, context=self._ssl_context, timeout=3) as resp:
                return resp.status == 200
        except Exception as e:
            logger.debug(f"Health check failed: {e}")
            return False

    def _post(self, path: str, payload) -> bool:
        url = self._base_url + path
        try:
            body = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                url,
                data=body,
                method="POST",
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, context=self._ssl_context, timeout=5) as resp:
                if resp.status == 200:
                    logger.debug(f"POST {path} → 200 OK")
                    return True
                logger.warning(f"POST {path} returned status {resp.status}")
                return False
        except urllib.error.URLError as e:
            logger.warning(f"POST {path} failed (server may be starting up): {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error posting to {path}: {e}")
            return False
