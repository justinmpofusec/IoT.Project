"""
storage/data_logger.py
----------------------
Handles structured logging of:
  - sensor readings  → logs/sensor_readings.jsonl
  - detected events  → logs/events.jsonl

Each log file is append-only JSONL (one JSON object per line).
Readings and events are also forwarded to the BlockchainLogger so that
every record is part of the tamper-evident chain.

Optionally persists readings to an SQLite database for structured queries.
"""

import json
import logging
import os
import sqlite3
from datetime import datetime, timezone

from storage.blockchain_logger import BlockchainLogger

logger = logging.getLogger(__name__)


class DataLogger:
    """
    Central structured data logger.

    Parameters
    ----------
    sensor_log_path : JSONL file for sensor readings
    event_log_path  : JSONL file for detected events
    chain_path      : JSONL file for blockchain-style audit trail
    db_path         : SQLite database path (None to disable)
    """

    def __init__(
        self,
        sensor_log_path: str = "logs/sensor_readings.jsonl",
        event_log_path: str = "logs/events.jsonl",
        chain_path: str = "blockchain/chain.jsonl",
        db_path: str = None,
    ):
        self.sensor_log_path = sensor_log_path
        self.event_log_path = event_log_path
        self.db_path = db_path

        # Ensure output directories exist
        for p in [sensor_log_path, event_log_path]:
            os.makedirs(os.path.dirname(p), exist_ok=True)

        # Blockchain audit trail
        self.chain = BlockchainLogger(chain_path)

        # Optional SQLite
        self._db_conn = None
        if db_path:
            self._init_db(db_path)

        logger.info("DataLogger initialised")

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def log_reading(self, reading: dict):
        """
        Persist a single sensor reading dict.

        reading format (from utils.helpers.build_reading):
            {timestamp, sensor, value, unit, status}
        """
        self._append_jsonl(self.sensor_log_path, reading)
        self.chain.append("reading", reading)

        if self._db_conn:
            self._insert_reading(reading)

        logger.debug(f"Reading logged: {reading['sensor']} = {reading['value']} {reading['unit']}")

    def log_event(self, event_type: str, details: dict, severity: str = "warning"):
        """
        Persist a detected event.

        Parameters
        ----------
        event_type : short label e.g. "intrusion_detected", "air_quality_critical"
        details    : free-form dict with context about the event
        severity   : "info" | "warning" | "critical"
        """
        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event_type": event_type,
            "severity": severity,
            "details": details,
        }
        self._append_jsonl(self.event_log_path, event)
        self.chain.append("event", event)

        if self._db_conn:
            self._insert_event(event)

        logger.info(f"Event logged [{severity.upper()}]: {event_type} — {details}")

    def log_system(self, message: str, metadata: dict = None):
        """Log a system-level event (startup, shutdown, config change) to the chain."""
        payload = {"message": message}
        if metadata:
            payload.update(metadata)
        self.chain.append("system", payload)

    def close(self):
        """Close any open database connections."""
        if self._db_conn:
            self._db_conn.close()
            logger.info("SQLite connection closed")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _append_jsonl(path: str, record: dict):
        """Append a dict as a single JSON line to a JSONL file."""
        try:
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except OSError as e:
            logger.error(f"Failed to write to {path}: {e}")

    # ---------- SQLite ----------

    def _init_db(self, db_path: str):
        """Create the SQLite database and tables if they do not exist."""
        os.makedirs(os.path.dirname(db_path) if os.path.dirname(db_path) else ".", exist_ok=True)
        try:
            self._db_conn = sqlite3.connect(db_path, check_same_thread=False)
            cursor = self._db_conn.cursor()
            cursor.executescript("""
                CREATE TABLE IF NOT EXISTS sensor_readings (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    sensor    TEXT NOT NULL,
                    value     REAL,
                    unit      TEXT,
                    status    TEXT
                );

                CREATE TABLE IF NOT EXISTS events (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp  TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    severity   TEXT,
                    details    TEXT
                );
            """)
            self._db_conn.commit()
            logger.info(f"SQLite database ready: {db_path}")
        except sqlite3.Error as e:
            logger.error(f"SQLite init failed: {e}. Disabling database logging.")
            self._db_conn = None

    def _insert_reading(self, reading: dict):
        try:
            self._db_conn.execute(
                "INSERT INTO sensor_readings (timestamp, sensor, value, unit, status) "
                "VALUES (?, ?, ?, ?, ?)",
                (
                    reading.get("timestamp"),
                    reading.get("sensor"),
                    reading.get("value"),
                    reading.get("unit"),
                    reading.get("status"),
                ),
            )
            self._db_conn.commit()
        except sqlite3.Error as e:
            logger.warning(f"SQLite insert reading failed: {e}")

    def _insert_event(self, event: dict):
        try:
            self._db_conn.execute(
                "INSERT INTO events (timestamp, event_type, severity, details) "
                "VALUES (?, ?, ?, ?)",
                (
                    event.get("timestamp"),
                    event.get("event_type"),
                    event.get("severity"),
                    json.dumps(event.get("details", {})),
                ),
            )
            self._db_conn.commit()
        except sqlite3.Error as e:
            logger.warning(f"SQLite insert event failed: {e}")
