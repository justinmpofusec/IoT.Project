"""
storage/logger_setup.py
-----------------------
Configures the root application logger with:
  - a rotating file handler (prevents unbounded log growth)
  - a console (stream) handler
  - a consistent log format including timestamp, level, and module

Call setup_logging() once at application startup before importing other modules.
"""

import logging
import os
from logging.handlers import RotatingFileHandler


def setup_logging(
    log_path: str = "logs/app.log",
    max_bytes: int = 1_048_576,
    backup_count: int = 3,
    level: int = logging.DEBUG,
):
    """
    Set up the root logger.

    Parameters
    ----------
    log_path     : path to the rotating log file
    max_bytes    : maximum file size before rotation (default 1 MB)
    backup_count : number of rotated files to keep
    level        : logging level (default DEBUG for development)
    """
    os.makedirs(os.path.dirname(log_path), exist_ok=True)

    log_format = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # Avoid adding duplicate handlers if setup_logging is called more than once
    if root_logger.handlers:
        return

    # Rotating file handler
    file_handler = RotatingFileHandler(
        log_path,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    file_handler.setFormatter(log_format)
    file_handler.setLevel(level)

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_format)
    console_handler.setLevel(logging.INFO)  # Keep console quieter than file

    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    logging.getLogger(__name__).info(
        f"Logging initialised → file: {log_path} | level: {logging.getLevelName(level)}"
    )
