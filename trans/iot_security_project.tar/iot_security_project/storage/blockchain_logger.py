"""
storage/blockchain_logger.py
----------------------------
Implements a local blockchain-inspired tamper-evident audit trail.

Each record written to the chain contains:
  - record_id   : sequential integer
  - timestamp   : UTC ISO 8601
  - record_type : "reading" | "event" | "system"
  - payload     : the data being recorded (dict)
  - prev_hash   : SHA-256 hash of the previous record's canonical string
  - current_hash: SHA-256 hash of this record's canonical string (excluding current_hash)

The chain is stored as a JSONL file (one JSON object per line) so it is
append-only, human-readable, and easy to parse.

The genesis block (record 0) has prev_hash = "0" * 64.
"""

import hashlib
import json
import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class BlockchainLogger:
    """
    Append-only tamper-evident chain logger.

    Usage
    -----
        bc = BlockchainLogger("blockchain/chain.jsonl")
        bc.append("reading", {"sensor": "air", "value": 120})
        bc.append("event",   {"type": "intrusion", "details": "..."})
    """

    GENESIS_HASH = "0" * 64

    def __init__(self, chain_path: str = "blockchain/chain.jsonl"):
        self.chain_path = chain_path
        os.makedirs(os.path.dirname(chain_path), exist_ok=True)

        # Load the last record to continue the chain
        self._last_hash, self._record_count = self._load_chain_tail()
        logger.info(
            f"BlockchainLogger ready | path={chain_path} "
            f"| existing_records={self._record_count}"
        )

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def append(self, record_type: str, payload: dict) -> dict:
        """
        Create and persist a new chain record.

        Parameters
        ----------
        record_type : category string ("reading", "event", "system")
        payload     : arbitrary dict of data to store

        Returns
        -------
        The fully formed chain record dict (including hashes).
        """
        record = self._build_record(record_type, payload)
        self._write_record(record)

        # Advance chain state
        self._last_hash = record["current_hash"]
        self._record_count += 1

        logger.debug(
            f"Chain record #{record['record_id']} appended "
            f"| type={record_type} | hash={record['current_hash'][:16]}..."
        )
        return record

    def get_record_count(self) -> int:
        """Return the total number of records currently in the chain."""
        return self._record_count

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_record(self, record_type: str, payload: dict) -> dict:
        """Construct a new record with hashes."""
        record = {
            "record_id": self._record_count,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "record_type": record_type,
            "payload": payload,
            "prev_hash": self._last_hash,
        }
        # Hash is computed over everything except current_hash itself
        record["current_hash"] = self._compute_hash(record)
        return record

    @staticmethod
    def _compute_hash(record: dict) -> str:
        """
        Compute SHA-256 hash over a canonical JSON representation of the record.
        The key 'current_hash' is excluded so the hash can be computed before
        it is known.
        """
        hashable = {k: v for k, v in record.items() if k != "current_hash"}
        canonical = json.dumps(hashable, sort_keys=True, ensure_ascii=True)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def _write_record(self, record: dict):
        """Append the record as a single JSON line to the chain file."""
        try:
            with open(self.chain_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except OSError as e:
            logger.error(f"Failed to write chain record: {e}")
            raise

    def _load_chain_tail(self) -> tuple:
        """
        Read the last record of an existing chain file to resume hashing.

        Returns
        -------
        (last_hash: str, record_count: int)
        """
        if not os.path.exists(self.chain_path):
            return self.GENESIS_HASH, 0

        last_hash = self.GENESIS_HASH
        count = 0
        try:
            with open(self.chain_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    record = json.loads(line)
                    last_hash = record.get("current_hash", self.GENESIS_HASH)
                    count += 1
        except (OSError, json.JSONDecodeError) as e:
            logger.warning(f"Could not fully read existing chain: {e}. Starting fresh.")
            return self.GENESIS_HASH, 0

        return last_hash, count
