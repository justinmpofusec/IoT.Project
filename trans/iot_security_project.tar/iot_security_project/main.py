"""
main.py
-------
Application entry point and main sensor client loop.

What this does
--------------
1. Loads configuration from config/client_conf.json
2. Sets up the logging system
3. Starts the local HTTPS server in a background thread
4. Initialises all sensors, the anomaly detector, the alerter,
   the data logger, and the MQTT publisher
5. Runs the sensor polling loop:
     a. Poll all sensors
     b. Log each reading locally (JSONL + blockchain chain)
     c. Run anomaly detection on the batch
     d. If events found: alert, log events, publish via MQTT
     e. POST readings and events to the local HTTPS server
     f. Wait for the configured polling interval
6. On KeyboardInterrupt: shuts down gracefully

Running
-------
    python main.py

To run WITHOUT starting the local server (client-only):
    python main.py --no-server

To verify the blockchain chain:
    python utils/verifier.py
"""

import argparse
import logging
import os
import signal
import sys
import threading
import time

# ---------------------------------------------------------------------------
# Ensure project root is on the Python path regardless of working directory
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

# ---------------------------------------------------------------------------
# Core imports — all project modules
# ---------------------------------------------------------------------------
from storage.logger_setup import setup_logging
from utils.helpers import load_config, ensure_directories, utc_now
from sensors.sensor_manager import SensorManager
from detection.detector import AnomalyDetector
from alerting.alerter import Alerter
from storage.data_logger import DataLogger
from server.https_client import HTTPSClient
from server.mqtt_publisher import MQTTPublisher

logger = logging.getLogger(__name__)

# Global flag for clean shutdown
_running = True


def signal_handler(sig, frame):
    """Handle SIGINT / SIGTERM gracefully."""
    global _running
    logger.info("Shutdown signal received — stopping sensor loop")
    _running = False


def start_server_thread(config: dict) -> threading.Thread:
    """
    Start the local HTTPS Flask server in a daemon thread so it does not
    block the main sensor loop.
    """
    from server.local_server import start_server

    thread = threading.Thread(
        target=start_server,
        kwargs={"config": config},
        daemon=True,
        name="LocalHTTPSServer",
    )
    thread.start()
    logger.info("Local HTTPS server thread started")
    # Brief pause to let the server start before the client begins posting
    time.sleep(2)
    return thread


def run_sensor_loop(
    sensor_mgr: SensorManager,
    detector: AnomalyDetector,
    alerter: Alerter,
    data_logger: DataLogger,
    https_client: HTTPSClient,
    mqtt_pub: MQTTPublisher,
    poll_interval: int,
):
    """
    Main sensor polling loop.

    Parameters
    ----------
    sensor_mgr    : SensorManager — reads all sensors
    detector      : AnomalyDetector — analyses readings
    alerter       : Alerter — dispatches alerts
    data_logger   : DataLogger — persists readings and events locally
    https_client  : HTTPSClient — posts to local server
    mqtt_pub      : MQTTPublisher — publishes to MQTT broker
    poll_interval : seconds between polls
    """
    global _running
    cycle = 0

    logger.info(f"Sensor loop starting | poll_interval={poll_interval}s")
    data_logger.log_system("Sensor loop started", {"poll_interval_s": poll_interval})

    while _running:
        cycle += 1
        logger.debug(f"--- Poll cycle #{cycle} ---")

        # 1. Read all sensors
        readings = sensor_mgr.poll_all()

        # 2. Log each reading locally (JSONL + blockchain)
        for reading in readings:
            data_logger.log_reading(reading)

        # 3. Analyse readings for anomalies
        events = detector.analyse(readings)

        # 4. If anomalies detected: alert and log
        if events:
            alerter.dispatch(events)
            for event in events:
                data_logger.log_event(
                    event["event_type"],
                    event.get("details", {}),
                    event.get("severity", "warning"),
                )

        # 5. POST to local server (non-blocking — failure is logged only)
        https_client.post_readings(readings)
        if events:
            https_client.post_events(events)

        # 6. Publish to MQTT (non-blocking — failure is logged only)
        if mqtt_pub.is_available:
            for reading in readings:
                mqtt_pub.publish_reading(reading)
            for event in events:
                mqtt_pub.publish_event(event)

        # 7. Summary line in console each cycle
        statuses = [r["status"] for r in readings]
        status_summary = ", ".join(f"{r['sensor']}={r['status']}" for r in readings)
        logger.info(f"Cycle #{cycle} | {status_summary} | events={len(events)}")

        time.sleep(poll_interval)

    logger.info("Sensor loop stopped")
    data_logger.log_system("Sensor loop stopped")


def main():
    # ------------------------------------------------------------------
    # Parse CLI arguments
    # ------------------------------------------------------------------
    parser = argparse.ArgumentParser(description="IoT Security Monitoring System")
    parser.add_argument(
        "--no-server",
        action="store_true",
        help="Skip starting the local HTTPS server (run client loop only)",
    )
    parser.add_argument(
        "--config",
        default="config/client_conf.json",
        help="Path to the JSON configuration file",
    )
    args = parser.parse_args()

    # ------------------------------------------------------------------
    # Load configuration
    # ------------------------------------------------------------------
    config = load_config(args.config)
    if not config:
        print("[FATAL] Could not load configuration. Check config/client_conf.json exists.")
        sys.exit(1)

    log_cfg = config.get("logging", {})
    chain_cfg = config.get("blockchain", {})
    precision = config.get("precision", 2)
    poll_interval = config.get("polling_interval_seconds", 5)

    # ------------------------------------------------------------------
    # Bootstrap directories and logging
    # ------------------------------------------------------------------
    ensure_directories([
        log_cfg.get("app_log_path", "logs/app.log"),
        log_cfg.get("sensor_log_path", "logs/sensor_readings.jsonl"),
        log_cfg.get("event_log_path", "logs/events.jsonl"),
        chain_cfg.get("chain_path", "blockchain/chain.jsonl"),
        "certs/",
        "data/",
    ])

    setup_logging(
        log_path=log_cfg.get("app_log_path", "logs/app.log"),
        max_bytes=log_cfg.get("max_log_bytes", 1_048_576),
        backup_count=log_cfg.get("backup_count", 3),
    )

    logger.info("=" * 60)
    logger.info("  IoT Security Monitoring System")
    logger.info(f"  Started at {utc_now()}")
    logger.info("=" * 60)

    # ------------------------------------------------------------------
    # Register shutdown signals
    # ------------------------------------------------------------------
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # ------------------------------------------------------------------
    # Start local HTTPS server in background thread
    # ------------------------------------------------------------------
    if not args.no_server:
        start_server_thread(config)

    # ------------------------------------------------------------------
    # Initialise all system components
    # ------------------------------------------------------------------
    sensor_mgr = SensorManager(config)

    data_logger = DataLogger(
        sensor_log_path=log_cfg.get("sensor_log_path", "logs/sensor_readings.jsonl"),
        event_log_path=log_cfg.get("event_log_path", "logs/events.jsonl"),
        chain_path=chain_cfg.get("chain_path", "blockchain/chain.jsonl"),
        db_path=os.path.join("data", "iot_readings.db"),
    )

    detector = AnomalyDetector(config)

    alerter = Alerter(
        config,
        led=sensor_mgr.led,
        buzzer=sensor_mgr.buzzer,
    )

    https_client = HTTPSClient(config)
    mqtt_pub = MQTTPublisher(config)

    # ------------------------------------------------------------------
    # Run the sensor loop (blocking until shutdown signal)
    # ------------------------------------------------------------------
    try:
        run_sensor_loop(
            sensor_mgr=sensor_mgr,
            detector=detector,
            alerter=alerter,
            data_logger=data_logger,
            https_client=https_client,
            mqtt_pub=mqtt_pub,
            poll_interval=poll_interval,
        )
    except Exception as e:
        logger.critical(f"Fatal error in sensor loop: {e}", exc_info=True)
    finally:
        data_logger.close()
        mqtt_pub.disconnect()
        logger.info("System shutdown complete")


if __name__ == "__main__":
    main()
