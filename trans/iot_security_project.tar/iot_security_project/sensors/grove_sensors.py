"""
sensors/grove_sensors.py
------------------------
Wrappers for all GrovePi-connected sensors used in this project:
  - Air quality sensor   (analog port A0)
  - Ultrasonic ranger    (digital port D6)
  - LED indicator        (digital port D2)
  - Buzzer               (digital port D3)

GrovePi is imported defensively: if the library is not installed or the
hardware is not connected, all sensor reads return None and all actuator
calls silently log a warning instead of crashing.

The module-level variable GROVEPI_AVAILABLE is set to True only when the
import succeeds and a basic sanity check passes.
"""

import logging
import time

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Defensive GrovePi import
# ---------------------------------------------------------------------------
try:
    import grovepi
    # Quick sanity check: version attribute exists in most grovepi builds
    GROVEPI_AVAILABLE = True
    logger.info("GrovePi library imported successfully")
except ImportError:
    GROVEPI_AVAILABLE = False
    logger.warning("GrovePi library not available — running in mock/fallback mode")
except Exception as e:
    GROVEPI_AVAILABLE = False
    logger.warning(f"GrovePi import error: {e} — running in mock/fallback mode")


# ---------------------------------------------------------------------------
# Air Quality Sensor (analog)
# ---------------------------------------------------------------------------

class AirQualitySensor:
    """
    Reads the Grove Air Quality sensor connected to an analog port.

    The raw ADC value (0–1023) correlates inversely with air quality:
      0–300   → clean
      300–600 → some pollution (warning)
      600+    → heavily polluted (critical)
    """

    def __init__(self, port: int = 0):
        self.port = port
        self._available = GROVEPI_AVAILABLE
        if self._available:
            try:
                grovepi.pinMode(self.port, "INPUT")
                logger.info(f"AirQualitySensor initialised on port A{port}")
            except Exception as e:
                logger.warning(f"AirQualitySensor setup failed on port A{port}: {e}")
                self._available = False

    def read_raw(self) -> int | None:
        """
        Return the raw ADC reading (0–1023), or None on failure.
        """
        if not self._available:
            return None
        try:
            value = grovepi.analogRead(self.port)
            # Sanity-check the range
            if not (0 <= value <= 1023):
                logger.warning(f"AirQualitySensor out-of-range value: {value}")
                return None
            return value
        except Exception as e:
            logger.error(f"AirQualitySensor read error: {e}")
            return None

    @property
    def is_available(self) -> bool:
        return self._available


# ---------------------------------------------------------------------------
# Ultrasonic Ranger (digital)
# ---------------------------------------------------------------------------

class UltrasonicSensor:
    """
    Reads the Grove Ultrasonic Ranger connected to a digital port.
    Returns distance in centimetres.
    """

    def __init__(self, port: int = 6):
        self.port = port
        self._available = GROVEPI_AVAILABLE
        if self._available:
            logger.info(f"UltrasonicSensor initialised on port D{port}")

    def read_cm(self) -> float | None:
        """
        Return distance in centimetres, or None on failure.
        The GrovePi ultrasonic ranger is reliable between ~2 cm and ~300 cm.
        """
        if not self._available:
            return None
        try:
            value = grovepi.ultrasonicRead(self.port)
            if value < 0 or value > 400:
                logger.warning(f"UltrasonicSensor implausible reading: {value} cm")
                return None
            return float(value)
        except Exception as e:
            logger.error(f"UltrasonicSensor read error: {e}")
            return None

    @property
    def is_available(self) -> bool:
        return self._available


# ---------------------------------------------------------------------------
# LED Actuator (digital)
# ---------------------------------------------------------------------------

class LEDController:
    """
    Controls a Grove LED connected to a digital port.
    Provides on(), off(), and blink() helpers.
    """

    def __init__(self, port: int = 2):
        self.port = port
        self._available = GROVEPI_AVAILABLE
        self._state = False  # Track current state

        if self._available:
            try:
                grovepi.pinMode(self.port, "OUTPUT")
                grovepi.digitalWrite(self.port, 0)
                logger.info(f"LEDController initialised on port D{port}")
            except Exception as e:
                logger.warning(f"LEDController setup failed on port D{port}: {e}")
                self._available = False

    def on(self):
        """Turn the LED on."""
        if not self._available:
            logger.debug("LED.on() called but LED not available")
            return
        try:
            grovepi.digitalWrite(self.port, 1)
            self._state = True
        except Exception as e:
            logger.error(f"LED on() failed: {e}")

    def off(self):
        """Turn the LED off."""
        if not self._available:
            return
        try:
            grovepi.digitalWrite(self.port, 0)
            self._state = False
        except Exception as e:
            logger.error(f"LED off() failed: {e}")

    def blink(self, times: int = 3, interval: float = 0.3):
        """Blink the LED a given number of times."""
        for _ in range(times):
            self.on()
            time.sleep(interval)
            self.off()
            time.sleep(interval)

    @property
    def is_available(self) -> bool:
        return self._available


# ---------------------------------------------------------------------------
# Buzzer Actuator (digital)
# ---------------------------------------------------------------------------

class BuzzerController:
    """
    Controls a Grove Buzzer connected to a digital port.
    Provides sound(), silence(), and beep() helpers.
    """

    def __init__(self, port: int = 3):
        self.port = port
        self._available = GROVEPI_AVAILABLE

        if self._available:
            try:
                grovepi.pinMode(self.port, "OUTPUT")
                grovepi.digitalWrite(self.port, 0)
                logger.info(f"BuzzerController initialised on port D{port}")
            except Exception as e:
                logger.warning(f"BuzzerController setup failed on port D{port}: {e}")
                self._available = False

    def sound(self):
        """Activate the buzzer."""
        if not self._available:
            logger.debug("Buzzer.sound() called but buzzer not available")
            return
        try:
            grovepi.digitalWrite(self.port, 1)
        except Exception as e:
            logger.error(f"Buzzer sound() failed: {e}")

    def silence(self):
        """Deactivate the buzzer."""
        if not self._available:
            return
        try:
            grovepi.digitalWrite(self.port, 0)
        except Exception as e:
            logger.error(f"Buzzer silence() failed: {e}")

    def beep(self, times: int = 2, duration: float = 0.2, gap: float = 0.1):
        """Sound the buzzer a given number of times."""
        for _ in range(times):
            self.sound()
            time.sleep(duration)
            self.silence()
            time.sleep(gap)

    @property
    def is_available(self) -> bool:
        return self._available
