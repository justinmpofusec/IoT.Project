"""
sensors/sensor_manager.py
--------------------------
Central sensor manager.

Responsibilities:
  - Instantiate all available sensor objects (GrovePi + Sense HAT)
  - Poll all sensors on each cycle
  - Normalise every reading into the standard dict format via helpers.build_reading
  - Classify each reading as "normal", "warning", or "critical" using thresholds
    from the configuration
  - Expose actuators (LED, buzzer) for use by the alerter

A mock/fallback reading is produced for any unavailable sensor so that the
pipeline always has something to work with (value=None, status="error").
"""

import logging
from typing import List

from sensors.grove_sensors import AirQualitySensor, UltrasonicSensor, LEDController, BuzzerController
from sensors.sensehat_sensors import SenseHatSensors
from utils.helpers import build_reading

logger = logging.getLogger(__name__)


class SensorManager:
    """
    Manages sensor hardware and produces standardised reading dicts.

    Parameters
    ----------
    config : the full configuration dict from client_conf.json
    """

    def __init__(self, config: dict):
        self.config = config
        self.precision = config.get("precision", 2)
        pins = config.get("pins", {})
        thresholds = config.get("thresholds", {})

        # Store thresholds for classification
        self._air_warn = thresholds.get("air_quality_warning", 300)
        self._air_crit = thresholds.get("air_quality_critical", 600)
        self._us_min = thresholds.get("ultrasonic_min_cm", 5)
        self._us_max = thresholds.get("ultrasonic_max_cm", 200)

        # Sensor objects
        self.air_sensor = AirQualitySensor(port=pins.get("air_sensor_port", 0))
        self.ultrasonic = UltrasonicSensor(port=pins.get("ultrasonic_port", 6))
        self.sensehat = SenseHatSensors()

        # Actuator objects (also owned here so the alerter can use them)
        self.led = LEDController(port=pins.get("led_port", 2))
        self.buzzer = BuzzerController(port=pins.get("buzzer_port", 3))

        logger.info(
            f"SensorManager ready | "
            f"air={self.air_sensor.is_available} | "
            f"ultrasonic={self.ultrasonic.is_available} | "
            f"sensehat={self.sensehat.is_available} | "
            f"led={self.led.is_available} | "
            f"buzzer={self.buzzer.is_available}"
        )

    def poll_all(self) -> List[dict]:
        """
        Read all sensors and return a list of standardised reading dicts.
        Always returns at least one entry per sensor (with status="error" if unavailable).
        """
        readings = []

        readings.append(self._read_air())
        readings.append(self._read_ultrasonic())

        # Sense HAT readings (only if available)
        if self.sensehat.is_available:
            readings.extend(self._read_sensehat())
        else:
            readings.append(build_reading("sensehat_temperature", None, "°C", "error", self.precision))

        return readings

    # ------------------------------------------------------------------
    # Private sensor read methods
    # ------------------------------------------------------------------

    def _read_air(self) -> dict:
        """Read the air quality sensor and classify the result."""
        if not self.air_sensor.is_available:
            return build_reading("air_quality", None, "ADC", "error", self.precision)

        raw = self.air_sensor.read_raw()
        if raw is None:
            return build_reading("air_quality", None, "ADC", "error", self.precision)

        if raw >= self._air_crit:
            status = "critical"
        elif raw >= self._air_warn:
            status = "warning"
        else:
            status = "normal"

        return build_reading("air_quality", raw, "ADC", status, self.precision)

    def _read_ultrasonic(self) -> dict:
        """Read the ultrasonic ranger and classify the result."""
        if not self.ultrasonic.is_available:
            return build_reading("ultrasonic_distance", None, "cm", "error", self.precision)

        cm = self.ultrasonic.read_cm()
        if cm is None:
            return build_reading("ultrasonic_distance", None, "cm", "error", self.precision)

        if cm < self._us_min or cm > self._us_max:
            status = "warning"
        else:
            status = "normal"

        return build_reading("ultrasonic_distance", cm, "cm", status, self.precision)

    def _read_sensehat(self) -> List[dict]:
        """Read all available Sense HAT environmental sensors."""
        readings = []

        temp = self.sensehat.read_temperature()
        readings.append(build_reading(
            "sensehat_temperature", temp, "°C",
            "normal" if temp is not None else "error",
            self.precision,
        ))

        humidity = self.sensehat.read_humidity()
        readings.append(build_reading(
            "sensehat_humidity", humidity, "%RH",
            "normal" if humidity is not None else "error",
            self.precision,
        ))

        pressure = self.sensehat.read_pressure()
        readings.append(build_reading(
            "sensehat_pressure", pressure, "mbar",
            "normal" if pressure is not None else "error",
            self.precision,
        ))

        return readings
