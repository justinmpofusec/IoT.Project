"""
sensors/sensehat_sensors.py
----------------------------
Optional Sense HAT environmental sensor wrapper.

Reads temperature, humidity, and pressure from the Sense HAT board if it
is connected and the sense_hat library is available.

If the Sense HAT is not present, all reads return None and the sensor
is marked unavailable — the rest of the system continues normally.
"""

import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Defensive Sense HAT import
# ---------------------------------------------------------------------------
try:
    from sense_hat import SenseHat as _SenseHat
    SENSE_HAT_AVAILABLE = True
    logger.info("sense_hat library imported successfully")
except ImportError:
    SENSE_HAT_AVAILABLE = False
    logger.info("sense_hat library not available — Sense HAT readings disabled")
except Exception as e:
    SENSE_HAT_AVAILABLE = False
    logger.warning(f"sense_hat import error: {e}")


class SenseHatSensors:
    """
    Thin wrapper around the Sense HAT environmental sensors.

    Provides individual methods for temperature, humidity, and pressure
    so that callers can use whichever readings they need.
    """

    def __init__(self):
        self._available = SENSE_HAT_AVAILABLE
        self._hat = None

        if self._available:
            try:
                self._hat = _SenseHat()
                self._hat.clear()
                logger.info("SenseHat initialised successfully")
            except Exception as e:
                logger.warning(f"SenseHat hardware init failed: {e}")
                self._available = False

    def read_temperature(self) -> float | None:
        """Return temperature in Celsius, or None if unavailable."""
        if not self._available or self._hat is None:
            return None
        try:
            return round(self._hat.get_temperature(), 2)
        except Exception as e:
            logger.error(f"SenseHat temperature read failed: {e}")
            return None

    def read_humidity(self) -> float | None:
        """Return relative humidity as a percentage, or None if unavailable."""
        if not self._available or self._hat is None:
            return None
        try:
            return round(self._hat.get_humidity(), 2)
        except Exception as e:
            logger.error(f"SenseHat humidity read failed: {e}")
            return None

    def read_pressure(self) -> float | None:
        """Return pressure in millibars, or None if unavailable."""
        if not self._available or self._hat is None:
            return None
        try:
            return round(self._hat.get_pressure(), 2)
        except Exception as e:
            logger.error(f"SenseHat pressure read failed: {e}")
            return None

    @property
    def is_available(self) -> bool:
        return self._available
