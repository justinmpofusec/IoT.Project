#!/bin/bash
# scripts/setup_mosquitto.sh
# --------------------------
# Installs Mosquitto MQTT broker and configures it to use TLS on port 8883
# with username/password authentication matching client_conf.json.
#
# Run AFTER gen_certs.sh so that certs/ already exists.
#
# Usage:
#   chmod +x scripts/setup_mosquitto.sh
#   sudo ./scripts/setup_mosquitto.sh

set -e

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
CERTS_DIR="$PROJECT_DIR/certs"
MOSQ_CONF="/etc/mosquitto/conf.d/iot_tls.conf"
MOSQ_PASSWD="/etc/mosquitto/passwd"
MQTT_USER="iotuser"
MQTT_PASS="iotpass123"

echo "=== Installing Mosquitto ==="
apt-get update -qq
apt-get install -y mosquitto mosquitto-clients

echo "=== Creating Mosquitto password file ==="
mosquitto_passwd -c -b "$MOSQ_PASSWD" "$MQTT_USER" "$MQTT_PASS"
chmod 600 "$MOSQ_PASSWD"

echo "=== Writing Mosquitto TLS configuration ==="
cat > "$MOSQ_CONF" <<EOF
# IoT Security Project — Mosquitto TLS Config
listener 8883
protocol mqtt

# TLS settings
cafile $CERTS_DIR/ca.crt
certfile $CERTS_DIR/server.crt
keyfile $CERTS_DIR/server.key
require_certificate false
tls_version tlsv1.2

# Authentication
password_file $MOSQ_PASSWD
allow_anonymous false

# Logging
log_type all
EOF

echo "=== Restarting Mosquitto ==="
systemctl enable mosquitto
systemctl restart mosquitto
systemctl status mosquitto --no-pager

echo ""
echo "Mosquitto TLS broker configured on port 8883"
echo "Username: $MQTT_USER"
echo "Password: $MQTT_PASS"
