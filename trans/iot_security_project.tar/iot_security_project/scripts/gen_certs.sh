#!/bin/bash
# scripts/gen_certs.sh
# --------------------
# Generates a self-signed CA, server certificate, and client certificate
# for use with the local HTTPS server and MQTT TLS broker.
#
# Output files (all in the certs/ directory):
#   ca.key      CA private key
#   ca.crt      CA certificate (self-signed)
#   server.key  Server private key
#   server.csr  Server certificate signing request
#   server.crt  Server certificate (signed by CA)
#   client.key  Client private key
#   client.csr  Client certificate signing request
#   client.crt  Client certificate (signed by CA)
#
# Usage:
#   chmod +x scripts/gen_certs.sh
#   ./scripts/gen_certs.sh
#
# Requires openssl to be installed:
#   sudo apt-get install -y openssl

set -e

CERTS_DIR="certs"
mkdir -p "$CERTS_DIR"
cd "$CERTS_DIR"

DAYS=3650
COUNTRY="GB"
STATE="England"
LOCALITY="London"
ORG="IoTSecurityProject"
CA_CN="IoT-Local-CA"
SERVER_CN="127.0.0.1"
CLIENT_CN="iot-client"

echo "=== Generating CA key and certificate ==="
openssl genrsa -out ca.key 2048
openssl req -new -x509 -days $DAYS -key ca.key -out ca.crt \
  -subj "/C=$COUNTRY/ST=$STATE/L=$LOCALITY/O=$ORG/CN=$CA_CN"

echo "=== Generating server key and CSR ==="
openssl genrsa -out server.key 2048
openssl req -new -key server.key -out server.csr \
  -subj "/C=$COUNTRY/ST=$STATE/L=$LOCALITY/O=$ORG/CN=$SERVER_CN"

echo "=== Signing server certificate with CA ==="
openssl x509 -req -days $DAYS -in server.csr -CA ca.crt -CAkey ca.key \
  -CAcreateserial -out server.crt \
  -extfile <(printf "subjectAltName=IP:127.0.0.1,DNS:localhost")

echo "=== Generating client key and CSR ==="
openssl genrsa -out client.key 2048
openssl req -new -key client.key -out client.csr \
  -subj "/C=$COUNTRY/ST=$STATE/L=$LOCALITY/O=$ORG/CN=$CLIENT_CN"

echo "=== Signing client certificate with CA ==="
openssl x509 -req -days $DAYS -in client.csr -CA ca.crt -CAkey ca.key \
  -CAcreateserial -out client.crt

echo ""
echo "=== Certificates generated in certs/ ==="
ls -lh .

cd ..
echo ""
echo "Done. TLS setup complete."
