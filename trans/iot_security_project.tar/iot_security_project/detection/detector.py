"""
detection/detector.py
----------------------
Rule-based anomaly and intrusion detection engine.

Detection rules implemented:
  1. Air quality threshold exceeded (warning or critical level from config)
  2. Ultrasonic distance outside the expected operating range
  3. Sudden distance change between consecutive readings — suggests movement
     or tampering near the sensor
  4. Repeated consecutive anomalies across N samples — persistent problem
  5. Sensor read errors — hardware fault or disconnection

All thresholds are read from configuration and can be changed in
config/client_conf.json without modifying code.

Events are emitted as dicts:
    {
        "event_type": "...",
        "severity": "warning|critical",
        "sensor": "...",
        "details": { ... }
    }
"""

import logging
from collections import deque
from typing import List, Optional

logger = logging.getLogger(__name__)


class AnomalyDetector:
    """
    Stateful detector that analyses incoming sensor readings.

    Maintains a short rolling window of recent readings per sensor
    to support multi-sample rules (e.g. rapid state change, repeated anomalies).

    Parameters
    ----------
    config : full configuration dict
    """

    def __init__(self, config: dict):
        thresholds = config.get("thresholds", {})

        self._air_warn = thresholds.get("air_quality_warning", 300)
        self._air_crit = thresholds.get("air_quality_critical", 600)
        self._us_min = thresholds.get("ultrasonic_min_cm", 5)
        self._us_max = thresholds.get("ultrasonic_max_cm", 200)
        self._sudden_change = thresholds.get("ultrasonic_sudden_change_cm", 40)
        self._consec_limit = thresholds.get("consecutive_anomalies_before_alert", 3)

        # Rolling windows: sensor_name → deque of recent values
        self._windows: dict[str, deque] = {}
        self._window_size = max(self._consec_limit + 2, 5)

        # Track previous distance for sudden-change detection
        self._prev_distance: Optional[float] = None

        # Consecutive anomaly counters per sensor
        self._consec_anomalies: dict[str, int] = {}

        logger.info(
            f"AnomalyDetector initialised | "
            f"air_warn={self._air_warn} | air_crit={self._air_crit} | "
            f"sudden_change_cm={self._sudden_change} | "
            f"consec_limit={self._consec_limit}"
        )

    def analyse(self, readings: List[dict]) -> List[dict]:
        """
        Analyse a list of sensor reading dicts and return a list of detected events.

        Parameters
        ----------
        readings : list of standardised reading dicts from SensorManager.poll_all()

        Returns
        -------
        list of event dicts (empty list if no anomalies detected)
        """
        events = []
        for reading in readings:
            self._update_window(reading)
            sensor_events = self._check_reading(reading)
            events.extend(sensor_events)
        return events

    # ------------------------------------------------------------------
    # Internal detection logic
    # ------------------------------------------------------------------

    def _check_reading(self, reading: dict) -> List[dict]:
        events = []
        sensor = reading.get("sensor", "unknown")
        value = reading.get("value")
        status = reading.get("status", "normal")

        # Rule: sensor error / unavailable
        if status == "error" or value is None:
            events.append(self._make_event(
                "sensor_error", "warning", sensor,
                {"message": f"Sensor '{sensor}' returned no data — check connection"},
            ))
            return events  # No further analysis possible without a value

        # Dispatch to sensor-specific rules
        if sensor == "air_quality":
            events.extend(self._check_air(sensor, value))
        elif sensor == "ultrasonic_distance":
            events.extend(self._check_ultrasonic(sensor, value))

        # Rule: consecutive anomalies for any sensor
        events.extend(self._check_consecutive(sensor, status))

        return events

    def _check_air(self, sensor: str, value: float) -> List[dict]:
        events = []
        if value >= self._air_crit:
            events.append(self._make_event(
                "air_quality_critical", "critical", sensor,
                {"value": value, "threshold": self._air_crit,
                 "message": "Air quality critically poor — possible gas leak or fire"},
            ))
        elif value >= self._air_warn:
            events.append(self._make_event(
                "air_quality_warning", "warning", sensor,
                {"value": value, "threshold": self._air_warn,
                 "message": "Air quality degraded — monitor closely"},
            ))
        return events

    def _check_ultrasonic(self, sensor: str, value: float) -> List[dict]:
        events = []

        # Rule: value outside expected operational range
        if value < self._us_min or value > self._us_max:
            events.append(self._make_event(
                "distance_out_of_range", "warning", sensor,
                {"value_cm": value, "min_cm": self._us_min, "max_cm": self._us_max,
                 "message": "Distance reading outside expected operating range"},
            ))

        # Rule: sudden change between consecutive readings — motion / intrusion
        if self._prev_distance is not None:
            change = abs(value - self._prev_distance)
            if change >= self._sudden_change:
                events.append(self._make_event(
                    "intrusion_motion_detected", "critical", sensor,
                    {
                        "current_cm": value,
                        "previous_cm": self._prev_distance,
                        "change_cm": round(change, 2),
                        "threshold_cm": self._sudden_change,
                        "message": "Rapid distance change detected — possible intrusion or tampering",
                    },
                ))
        self._prev_distance = value
        return events

    def _check_consecutive(self, sensor: str, status: str) -> List[dict]:
        """Detect when a sensor has been in anomaly state for N consecutive readings."""
        if status in ("warning", "critical", "error"):
            self._consec_anomalies[sensor] = self._consec_anomalies.get(sensor, 0) + 1
        else:
            self._consec_anomalies[sensor] = 0

        count = self._consec_anomalies.get(sensor, 0)
        if count == self._consec_limit:
            return [self._make_event(
                "persistent_anomaly", "warning", sensor,
                {
                    "consecutive_count": count,
                    "message": f"Sensor '{sensor}' has been in anomaly state for "
                               f"{count} consecutive readings",
                },
            )]
        return []

    def _update_window(self, reading: dict):
        """Add the latest value to the rolling window for this sensor."""
        sensor = reading.get("sensor", "unknown")
        if sensor not in self._windows:
            self._windows[sensor] = deque(maxlen=self._window_size)
        self._windows[sensor].append(reading.get("value"))

    @staticmethod
    def _make_event(event_type: str, severity: str, sensor: str, details: dict) -> dict:
        return {
            "event_type": event_type,
            "severity": severity,
            "sensor": sensor,
            "details": details,
        }
