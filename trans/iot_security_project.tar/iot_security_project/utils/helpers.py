"""
utils/helpers.py
----------------
Shared utility functions used across the project:
  - configuration loading
  - timestamp generation
  - safe numeric rounding
  - directory bootstrapping
"""

import json
import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


def load_config(config_path: str = "config/client_conf.json") -> dict:
    """
    Load the JSON configuration file.
    Returns an empty dict and logs an error if the file is missing or malformed.
    """
    if not os.path.exists(config_path):
        logger.error(f"Config file not found: {config_path}")
        return {}
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
        logger.info(f"Configuration loaded from {config_path}")
        return config
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse config file {config_path}: {e}")
        return {}


def utc_now() -> str:
    """Return the current UTC time as an ISO 8601 string."""
    return datetime.now(timezone.utc).isoformat()


def safe_round(value, precision: int = 2):
    """
    Safely round a numeric value. Returns None if value is not numeric.
    """
    try:
        return round(float(value), precision)
    except (TypeError, ValueError):
        return None


def ensure_directories(paths: list):
    """
    Create directories for each path in the list if they do not already exist.
    Accepts both file paths (extracts directory) and directory paths.
    """
    for path in paths:
        directory = os.path.dirname(path) if "." in os.path.basename(path) else path
        if directory and not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)
            logger.debug(f"Created directory: {directory}")


def build_reading(sensor_name: str, value, unit: str, status: str, precision: int = 2) -> dict:
    """
    Construct a standardised sensor reading dictionary.

    Format:
        {
            "timestamp": "<ISO 8601 UTC>",
            "sensor": "<name>",
            "value": <rounded float or None>,
            "unit": "<unit string>",
            "status": "normal|warning|critical|error"
        }
    """
    return {
        "timestamp": utc_now(),
        "sensor": sensor_name,
        "value": safe_round(value, precision),
        "unit": unit,
        "status": status,
    }
