"""
utils/verifier.py
-----------------
Standalone CLI tool to verify the integrity of the blockchain-inspired audit
chain stored in blockchain/chain.jsonl (or a custom path).

Run with:
    python utils/verifier.py
    python utils/verifier.py --chain blockchain/chain.jsonl

Verification checks:
  1. Each record's current_hash matches a fresh SHA-256 of its contents.
  2. Each record's prev_hash matches the current_hash of the preceding record.
  3. The genesis record's prev_hash is the expected all-zero string.

Any mismatch indicates tampering or corruption.
"""

import argparse
import hashlib
import json
import os
import sys


GENESIS_HASH = "0" * 64


def compute_hash(record: dict) -> str:
    """Recompute the hash for a record, excluding the 'current_hash' field."""
    hashable = {k: v for k, v in record.items() if k != "current_hash"}
    canonical = json.dumps(hashable, sort_keys=True, ensure_ascii=True)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def verify_chain(chain_path: str) -> bool:
    """
    Verify the integrity of every record in the chain file.

    Returns True if the chain is valid, False if any anomaly is detected.
    Prints a detailed report to stdout.
    """
    if not os.path.exists(chain_path):
        print(f"[ERROR] Chain file not found: {chain_path}")
        return False

    records = []
    try:
        with open(chain_path, "r", encoding="utf-8") as f:
            for lineno, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError as e:
                    print(f"[ERROR] Line {lineno}: invalid JSON — {e}")
                    return False
    except OSError as e:
        print(f"[ERROR] Cannot read chain file: {e}")
        return False

    if not records:
        print("[INFO] Chain file is empty — nothing to verify.")
        return True

    print(f"\n{'='*60}")
    print(f"  Blockchain Integrity Verifier")
    print(f"  Chain file : {chain_path}")
    print(f"  Records    : {len(records)}")
    print(f"{'='*60}\n")

    all_valid = True
    expected_prev = GENESIS_HASH

    for i, record in enumerate(records):
        record_id = record.get("record_id", i)
        stored_hash = record.get("current_hash", "")
        stored_prev = record.get("prev_hash", "")
        recomputed = compute_hash(record)

        hash_ok = stored_hash == recomputed
        prev_ok = stored_prev == expected_prev

        if hash_ok and prev_ok:
            status = "OK"
        else:
            status = "FAIL"
            all_valid = False

        print(f"  Record #{record_id:>4} | {status}", end="")
        if not hash_ok:
            print(f"\n    [!] Hash mismatch: stored={stored_hash[:16]}... expected={recomputed[:16]}...", end="")
        if not prev_ok:
            print(f"\n    [!] Prev hash mismatch: stored={stored_prev[:16]}... expected={expected_prev[:16]}...", end="")
        print()

        # Advance expected prev_hash regardless so we can continue checking
        expected_prev = stored_hash

    print(f"\n{'='*60}")
    if all_valid:
        print("  RESULT: Chain is VALID — no tampering detected.")
    else:
        print("  RESULT: Chain is INVALID — one or more records are corrupted or tampered.")
    print(f"{'='*60}\n")

    return all_valid


def main():
    parser = argparse.ArgumentParser(description="Verify the IoT blockchain audit chain.")
    parser.add_argument(
        "--chain",
        default="blockchain/chain.jsonl",
        help="Path to the chain JSONL file (default: blockchain/chain.jsonl)",
    )
    args = parser.parse_args()

    valid = verify_chain(args.chain)
    sys.exit(0 if valid else 1)


if __name__ == "__main__":
    main()
