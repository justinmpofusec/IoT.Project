"""
alerting/alerter.py
-------------------
Alert dispatcher.

When an event is detected by the AnomalyDetector, the Alerter decides
how to notify the operator based on alert flags in the configuration:

  - console : print a formatted alert to stdout
  - file    : write to the application log at WARNING or CRITICAL level
  - led     : blink the LED (more blinks for higher severity)
  - buzzer  : beep the buzzer (more beeps for higher severity)
  - lcd     : write to Grove RGB LCD if available (disabled by default
              since LCD is not in the current hardware set)

The Alerter is intentionally decoupled from detection logic — it receives
a list of event dicts and acts on them.
"""

import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

# Defensive LCD import — not available in current hardware but handled cleanly
try:
    from grove_rgb_lcd import setRGB, setText
    LCD_LIB_AVAILABLE = True
except ImportError:
    LCD_LIB_AVAILABLE = False


class Alerter:
    """
    Multi-channel alert dispatcher.

    Parameters
    ----------
    config       : full configuration dict
    led          : LEDController instance (from SensorManager)
    buzzer       : BuzzerController instance (from SensorManager)
    """

    def __init__(self, config: dict, led=None, buzzer=None):
        alert_cfg = config.get("alerts", {})

        self.enable_console = alert_cfg.get("enable_console", True)
        self.enable_file = alert_cfg.get("enable_file", True)
        self.enable_led = alert_cfg.get("enable_led", True)
        self.enable_buzzer = alert_cfg.get("enable_buzzer", True)
        self.enable_lcd = alert_cfg.get("enable_lcd", False) and LCD_LIB_AVAILABLE

        self._led = led
        self._buzzer = buzzer

        logger.info(
            f"Alerter configured | "
            f"console={self.enable_console} | file={self.enable_file} | "
            f"led={self.enable_led} | buzzer={self.enable_buzzer} | "
            f"lcd={self.enable_lcd}"
        )

    def dispatch(self, events: list):
        """
        Process a list of event dicts and fire the appropriate alerts.
        Each event dict must have keys: event_type, severity, sensor, details.
        """
        for event in events:
            severity = event.get("severity", "warning")
            event_type = event.get("event_type", "unknown_event")
            sensor = event.get("sensor", "?")
            details = event.get("details", {})
            message = details.get("message", event_type)

            if self.enable_console:
                self._console_alert(severity, event_type, sensor, message, details)

            if self.enable_file:
                self._file_alert(severity, event_type, sensor, message, details)

            if self.enable_led and self._led:
                self._led_alert(severity)

            if self.enable_buzzer and self._buzzer:
                self._buzzer_alert(severity)

            if self.enable_lcd:
                self._lcd_alert(severity, message)

    # ------------------------------------------------------------------
    # Alert channel implementations
    # ------------------------------------------------------------------

    def _console_alert(self, severity: str, event_type: str, sensor: str,
                       message: str, details: dict):
        """Print a clearly formatted alert to stdout."""
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        border = "!" * 60 if severity == "critical" else "-" * 60
        print(f"\n{border}")
        print(f"  [{severity.upper()}] {ts}")
        print(f"  Event   : {event_type}")
        print(f"  Sensor  : {sensor}")
        print(f"  Message : {message}")
        # Print any numeric details
        for k, v in details.items():
            if k != "message":
                print(f"  {k:12}: {v}")
        print(f"{border}\n")

    def _file_alert(self, severity: str, event_type: str, sensor: str,
                    message: str, details: dict):
        """Log the alert to the application log file."""
        log_message = f"ALERT [{severity.upper()}] {event_type} | sensor={sensor} | {message} | {details}"
        if severity == "critical":
            logger.critical(log_message)
        else:
            logger.warning(log_message)

    def _led_alert(self, severity: str):
        """Blink the LED — more blinks for critical severity."""
        if not self._led or not self._led.is_available:
            return
        times = 5 if severity == "critical" else 2
        interval = 0.15 if severity == "critical" else 0.3
        self._led.blink(times=times, interval=interval)

    def _buzzer_alert(self, severity: str):
        """Sound the buzzer — more beeps for critical severity."""
        if not self._buzzer or not self._buzzer.is_available:
            return
        times = 3 if severity == "critical" else 1
        duration = 0.3 if severity == "critical" else 0.2
        self._buzzer.beep(times=times, duration=duration)

    def _lcd_alert(self, severity: str, message: str):
        """Display a status message on the Grove RGB LCD if enabled."""
        if not LCD_LIB_AVAILABLE:
            return
        try:
            if severity == "critical":
                setRGB(255, 0, 0)     # Red background for critical
            else:
                setRGB(255, 165, 0)   # Orange for warning

            # LCD is typically 16 chars wide x 2 rows
            display_text = message[:32] if len(message) > 32 else message
            setText(display_text)
        except Exception as e:
            logger.warning(f"LCD alert failed: {e}")
